from info import __doc__
from core import *

from numpy.testing import Tester
test = Tester().test


